<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>PayloadContent</key>
	<array>
		<dict>
			<key>DNSSettings</key>
			<dict>
				<key>DNSProtocol</key>
				<string>HTTPS</string>
				<key>ServerURL</key>
				<string>https://doh.familyshield.opendns.com/dns-query</string>
			</dict>
			<key>PayloadDescription</key>
			<string>OpenDNS FamilyShield over HTTPS</string>
			<key>PayloadDisplayName</key>
			<string>OpenDNS FamilyShield</string>
			<key>PayloadIdentifier</key>
			<string>com.apple.dnsSettings.managed.650b10a7-6355-4576-a549-d3975a1e29f1</string>
			<key>PayloadType</key>
			<string>com.apple.dnsSettings.managed</string>
			<key>PayloadUUID</key>
			<string>650b10a7-6355-4576-a549-d3975a1e29f1</string>
			<key>PayloadVersion</key>
			<integer>1</integer>
			<key>ProhibitDisablement</key>
			<false/>
		</dict>
	</array>
	<key>PayloadDescription</key>
	<string>OpenDNS FamilyShield over HTTPS</string>
	<key>PayloadDisplayName</key>
	<string>OpenDNS FamilyShield</string>
	<key>PayloadIdentifier</key>
	<string>familyShield</string>
	<key>PayloadOrganization</key>
	<string>Janpreet Singh</string>
	<key>PayloadRemovalDisallowed</key>
	<false/>
	<key>PayloadType</key>
	<string>Configuration</string>
	<key>PayloadUUID</key>
	<string>79CAC10D-F6BF-4372-9C13-B0AE0EC1E48D</string>
	<key>PayloadVersion</key>
	<integer>1</integer>
</dict>
</plist>